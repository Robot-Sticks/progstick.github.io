#ifndef __CH32YYXX_DAC_H_
#define __CH32YYXX_DAC_H_

#if defined(CH32V30x) || defined(CH32V30x_C)
#include "ch32v30x_dac.h"
#endif

#endif /* __CH32YYXX_DAC_H_ */